from setuptools import setup, find_packages
setup(
    name='pkprime',
    version= '1.0.0',
    author= 'Vu Duy Khuong',
    author_email= 'khuong@gmail.com' ,
    description= ' A package for checking prime numbers',
    packages = find_packages(),
)