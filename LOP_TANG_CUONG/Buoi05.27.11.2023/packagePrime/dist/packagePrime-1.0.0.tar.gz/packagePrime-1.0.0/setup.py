from setuptools import setup, find_packages
setup(
    name = 'packagePrime',
    version = '1.0.0',
    author = 'KhuongDuy',
    author_email = 'khuong@gmail.com',
    description = 'A pacakge for checking prime numbers',
    packages = find_packages()
)